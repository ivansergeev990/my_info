import {EventEmitter} from 'events';
const Events = new EventEmitter();
export default Events;
