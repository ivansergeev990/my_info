import * as React from "react";
import Account from "../Account/"

function Home(props) {
    return (
        <>
            <Account />
        </>
    );
}
export default Home;
