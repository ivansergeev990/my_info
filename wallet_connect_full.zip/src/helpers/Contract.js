import { useWeb3React } from "@web3-react/core";
import { ethers } from "ethers";
export const TOWERGAMECONTRACTADDRESS='0x751Fc45d902307B2d0375f946BAac827C24f1303'
//export const TOWERGAMECONTRACTADDRESS='0x6375Bfd7cF42f9A32f63235c037eeBedB7dD4298'
export const GetContract = (contractAddress, abi) => {
    const { library, account } = useWeb3React();
    
    let contract;

    try {
        const provider = new ethers.providers.Web3Provider(library.provider);
        const signer = provider.getSigner();
        contract = new ethers.Contract(contractAddress, abi, signer);
    } catch (error) {
        contract = null;
    }
    return contract;
};
